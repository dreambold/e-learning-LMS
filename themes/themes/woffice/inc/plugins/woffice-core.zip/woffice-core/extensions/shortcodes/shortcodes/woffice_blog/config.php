<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Blog Posts', 'woffice' ),
	'description' => __( 'Lastest blog posts.', 'woffice' ),
	'tab'         => __( 'Content Elements', 'woffice' ),
	'icon' 		  => 'fa fa-newspaper-o ',
);